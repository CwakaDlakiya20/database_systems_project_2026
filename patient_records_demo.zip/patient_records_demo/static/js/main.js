document.querySelectorAll('form[onsubmit]').forEach(form=>{});
setTimeout(()=>document.querySelectorAll('.alert').forEach(el=>{el.style.transition='opacity .5s';el.style.opacity='0';setTimeout(()=>el.remove(),500)}),5000);
