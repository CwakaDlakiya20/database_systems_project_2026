# Rural Clinic Electronic Patient Record System

This project converts the original student-records Flask/MySQL demonstration into a rural clinic Electronic Patient Record (EPR) demonstration based on the supplied project documentation.

## Core tables
1. patients
2. doctors
3. nurses
4. appointments
5. consultations
6. diagnoses
7. medications
8. prescriptions
9. users
10. audit_log

## Main workflow
Patient registration -> appointment -> consultation -> diagnosis/prescription -> audit logging.

## Roles
- Administrator: system management, medication inventory and audit log.
- Doctor: patient records, consultations, diagnoses and prescriptions.
- Nurse: relevant patient and clinical information.
- Receptionist: patient registration and appointments.

## Setup
1. Create a MySQL database by running `database/project.sql`.
2. Create a Python virtual environment.
3. Install dependencies: `pip install -r requirements.txt`.
4. Set DB_HOST, DB_USER, DB_PASSWORD and DB_NAME if your MySQL settings differ.
5. Run `python app.py`.

Demo password for all demo users: `Password123!`

This is a university demonstration. Do not place real patient information into it. A production clinic deployment would require additional security, privacy controls, infrastructure, backup testing and compliance work.

## Backup and recovery demonstration

Create a backup with:

`python database/backup.py`

Restore a trusted backup with:

`python database/restore.py database/backups/your_backup.sql`

The scripts use the MySQL `mysqldump` and `mysql` command-line utilities. In a production environment, backups should be encrypted, access-controlled, stored separately, and regularly tested.
