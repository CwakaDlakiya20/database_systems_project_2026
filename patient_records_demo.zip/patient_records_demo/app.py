from flask import Flask, render_template, request, redirect, url_for, session, flash, abort
from functools import wraps
from werkzeug.security import check_password_hash
import mysql.connector
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "rural-clinic-demo-change-me")

DB_CONFIG = {
    "host": "127.0.0.1",
    "user": "root",
    "password": "n3wP@ssw0rd",
    "database": "rural_clinic",
}


def get_db():
    return mysql.connector.connect(**DB_CONFIG)


def query(sql, params=(), one=False):
    conn = get_db()
    cur = conn.cursor(dictionary=True)
    try:
        cur.execute(sql, params)
        rows = cur.fetchall()
        return rows[0] if one and rows else (None if one else rows)
    finally:
        cur.close(); conn.close()


def execute(sql, params=()):
    conn = get_db(); cur = conn.cursor()
    try:
        cur.execute(sql, params); conn.commit(); return cur.lastrowid
    finally:
        cur.close(); conn.close()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def role_required(*roles):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if "user_id" not in session:
                return redirect(url_for("login"))
            if session.get("role") not in roles:
                flash("You are not authorised to access that page.", "danger")
                return redirect(url_for("dashboard"))
            return view(*args, **kwargs)
        return wrapped
    return decorator


def audit(action, table_name, record_id=None, description=""):
    if session.get("user_id"):
        execute("INSERT INTO audit_log(user_id,action,table_name,record_id,description) VALUES (%s,%s,%s,%s,%s)",
                (session["user_id"], action, table_name, record_id, description))


@app.route("/")
def index():
    return redirect(url_for("dashboard" if "user_id" in session else "login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        user = query("SELECT * FROM users WHERE username=%s AND account_status='Active'", (username,), one=True)
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session.update(user_id=user["user_id"], username=user["username"], role=user["role"],
                           doctor_id=user["doctor_id"], nurse_id=user["nurse_id"])
            execute("UPDATE users SET last_login=NOW() WHERE user_id=%s", (user["user_id"],))
            audit("LOGIN", "users", user["user_id"], "Successful login")
            return redirect(url_for("dashboard"))
        flash("Invalid username or password.", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    if session.get("user_id"):
        audit("LOGOUT", "users", session["user_id"], "User logged out")
    session.clear(); return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    return redirect(url_for({
        "administrator": "admin_dashboard",
        "doctor": "doctor_dashboard",
        "nurse": "nurse_dashboard",
        "receptionist": "receptionist_dashboard"
    }[session["role"]]))


@app.route("/receptionist")
@role_required("receptionist", "administrator")
def receptionist_dashboard():
    counts = {
        "patients": query("SELECT COUNT(*) n FROM patients", one=True)["n"],
        "today": query("SELECT COUNT(*) n FROM appointments WHERE appointment_date=CURRENT_DATE", one=True)["n"],
        "scheduled": query("SELECT COUNT(*) n FROM appointments WHERE status='Scheduled'", one=True)["n"],
    }
    appointments = query("""SELECT a.*, CONCAT(p.first_name,' ',p.last_name) patient_name,
        CONCAT(d.first_name,' ',d.last_name) doctor_name FROM appointments a
        JOIN patients p ON p.patient_id=a.patient_id JOIN doctors d ON d.doctor_id=a.doctor_id
        WHERE a.appointment_date=CURRENT_DATE ORDER BY a.appointment_time""")
    return render_template("receptionist_dashboard.html", counts=counts, appointments=appointments)


@app.route("/doctor")
@role_required("doctor", "administrator")
def doctor_dashboard():
    doctor_id = session.get("doctor_id")
    appointments = query("""SELECT a.*, CONCAT(p.first_name,' ',p.last_name) patient_name
        FROM appointments a JOIN patients p ON p.patient_id=a.patient_id
        WHERE (%s IS NULL OR a.doctor_id=%s) AND a.appointment_date=CURRENT_DATE
        ORDER BY a.appointment_time""", (doctor_id, doctor_id))
    consultations = query("""SELECT c.*, CONCAT(p.first_name,' ',p.last_name) patient_name
        FROM consultations c JOIN patients p ON p.patient_id=c.patient_id
        WHERE (%s IS NULL OR c.doctor_id=%s) ORDER BY c.consultation_date DESC LIMIT 8""", (doctor_id, doctor_id))
    return render_template("doctor_dashboard.html", appointments=appointments, consultations=consultations)


@app.route("/nurse")
@role_required("nurse", "administrator")
def nurse_dashboard():
    appointments = query("""SELECT a.*, CONCAT(p.first_name,' ',p.last_name) patient_name,
        CONCAT(d.first_name,' ',d.last_name) doctor_name FROM appointments a
        JOIN patients p ON p.patient_id=a.patient_id JOIN doctors d ON d.doctor_id=a.doctor_id
        WHERE a.appointment_date=CURRENT_DATE ORDER BY a.appointment_time""")
    return render_template("nurse_dashboard.html", appointments=appointments)


@app.route("/admin")
@role_required("administrator")
def admin_dashboard():
    counts = {k: query(f"SELECT COUNT(*) n FROM {t}", one=True)["n"] for k,t in {
        "patients":"patients","doctors":"doctors","nurses":"nurses","appointments":"appointments",
        "consultations":"consultations","medications":"medications","users":"users","audit":"audit_log"}.items()}
    return render_template("admin_dashboard.html", counts=counts)


@app.route("/patients")
@login_required
def patients():
    term = request.args.get("q", "").strip()
    if term:
        like = f"%{term}%"
        rows = query("""SELECT * FROM patients WHERE CAST(patient_id AS CHAR) LIKE %s
            OR first_name LIKE %s OR last_name LIKE %s OR phone_number LIKE %s OR village LIKE %s
            ORDER BY last_name, first_name""", (like,like,like,like,like))
    else:
        rows = query("SELECT * FROM patients ORDER BY last_name, first_name")
    return render_template("patients.html", patients=rows, search=term)


@app.post("/patients/add")
@role_required("receptionist", "administrator")
def add_patient():
    keys = ["first_name","last_name","date_of_birth","gender","id_number","phone_number","address","village","emergency_contact_name","emergency_contact_phone"]
    try:
        patient_id = execute("""INSERT INTO patients(first_name,last_name,date_of_birth,gender,id_number,phone_number,address,village,emergency_contact_name,emergency_contact_phone)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""", tuple(request.form.get(k) or None for k in keys))
        audit("INSERT", "patients", patient_id, "Patient registered")
        flash(f"Patient registered with ID {patient_id}.", "success")
    except mysql.connector.Error as e:
        flash(f"Could not register patient: {e.msg}", "danger")
    return redirect(url_for("patients"))


@app.route("/patients/<int:patient_id>")
@login_required
def patient_record(patient_id):
    patient = query("SELECT * FROM patients WHERE patient_id=%s", (patient_id,), one=True)
    if not patient: abort(404)
    appointments = query("""SELECT a.*, CONCAT(d.first_name,' ',d.last_name) doctor_name
        FROM appointments a JOIN doctors d ON d.doctor_id=a.doctor_id WHERE a.patient_id=%s
        ORDER BY a.appointment_date DESC,a.appointment_time DESC""", (patient_id,))
    consultations = query("""SELECT c.*, CONCAT(d.first_name,' ',d.last_name) doctor_name,
        CONCAT(COALESCE(n.first_name,''),' ',COALESCE(n.last_name,'')) nurse_name
        FROM consultations c JOIN doctors d ON d.doctor_id=c.doctor_id LEFT JOIN nurses n ON n.nurse_id=c.nurse_id
        WHERE c.patient_id=%s ORDER BY c.consultation_date DESC""", (patient_id,))
    diagnoses = query("""SELECT dg.*, c.consultation_date FROM diagnoses dg JOIN consultations c ON c.consultation_id=dg.consultation_id
        WHERE c.patient_id=%s ORDER BY dg.diagnosis_date DESC""", (patient_id,))
    prescriptions = query("""SELECT pr.*, m.medication_name,m.strength,c.consultation_date FROM prescriptions pr
        JOIN medications m ON m.medication_id=pr.medication_id JOIN consultations c ON c.consultation_id=pr.consultation_id
        WHERE c.patient_id=%s ORDER BY c.consultation_date DESC""", (patient_id,))
    return render_template("patient_record.html", patient=patient, appointments=appointments,
                           consultations=consultations, diagnoses=diagnoses, prescriptions=prescriptions,
                           doctors=query("SELECT doctor_id,first_name,last_name FROM doctors ORDER BY last_name"),
                           nurses=query("SELECT nurse_id,first_name,last_name FROM nurses ORDER BY last_name"),
                           medications=query("SELECT medication_id,medication_name,strength,quantity_available FROM medications WHERE quantity_available > 0 ORDER BY medication_name"))


@app.route("/appointments")
@login_required
def appointments():
    rows = query("""SELECT a.*, CONCAT(p.first_name,' ',p.last_name) patient_name,
        CONCAT(d.first_name,' ',d.last_name) doctor_name FROM appointments a
        JOIN patients p ON p.patient_id=a.patient_id JOIN doctors d ON d.doctor_id=a.doctor_id
        ORDER BY a.appointment_date DESC,a.appointment_time DESC""")
    return render_template("appointments.html", appointments=rows,
                           patients=query("SELECT patient_id,first_name,last_name FROM patients ORDER BY last_name"),
                           doctors=query("SELECT doctor_id,first_name,last_name FROM doctors ORDER BY last_name"))


@app.post("/appointments/add")
@role_required("receptionist", "administrator")
def add_appointment():
    aid = execute("""INSERT INTO appointments(patient_id,doctor_id,appointment_date,appointment_time,reason,status)
        VALUES (%s,%s,%s,%s,%s,'Scheduled')""", tuple(request.form.get(k) for k in ["patient_id","doctor_id","appointment_date","appointment_time","reason"]))
    audit("INSERT", "appointments", aid, "Appointment created")
    flash("Appointment created.", "success"); return redirect(url_for("appointments"))


@app.post("/appointments/<int:appointment_id>/status")
@role_required("receptionist", "administrator", "doctor")
def update_appointment_status(appointment_id):
    status = request.form.get("status")
    if status not in {"Scheduled","Completed","Cancelled","No-show"}: abort(400)
    execute("UPDATE appointments SET status=%s WHERE appointment_id=%s", (status, appointment_id))
    audit("UPDATE", "appointments", appointment_id, f"Appointment status changed to {status}")
    flash("Appointment updated.", "success"); return redirect(request.referrer or url_for("appointments"))


@app.post("/consultations/add")
@role_required("doctor", "nurse", "administrator")
def add_consultation():
    if session["role"] == "doctor" and session.get("doctor_id"):
        doctor_id = session["doctor_id"]
    else:
        doctor_id = request.form.get("doctor_id")
    cid = execute("""INSERT INTO consultations(patient_id,doctor_id,nurse_id,consultation_date,symptoms,blood_pressure,temperature,weight,clinical_notes,treatment_notes)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""", tuple([request.form.get("patient_id"),doctor_id,request.form.get("nurse_id") or None,
        request.form.get("consultation_date"),request.form.get("symptoms"),request.form.get("blood_pressure"),request.form.get("temperature") or None,
        request.form.get("weight") or None,request.form.get("clinical_notes"),request.form.get("treatment_notes")]))
    audit("INSERT", "consultations", cid, "Consultation recorded")
    flash("Consultation saved.", "success"); return redirect(url_for("patient_record", patient_id=request.form.get("patient_id")))


@app.post("/diagnoses/add")
@role_required("doctor", "administrator")
def add_diagnosis():
    did = execute("INSERT INTO diagnoses(consultation_id,diagnosis_name,description) VALUES (%s,%s,%s)",
                  (request.form.get("consultation_id"),request.form.get("diagnosis_name"),request.form.get("description")))
    audit("INSERT", "diagnoses", did, "Diagnosis recorded")
    return redirect(request.referrer or url_for("patients"))


@app.post("/prescriptions/add")
@role_required("doctor", "administrator")
def add_prescription():
    pid = execute("""INSERT INTO prescriptions(consultation_id,medication_id,dosage,frequency,duration,quantity,instructions)
        VALUES (%s,%s,%s,%s,%s,%s,%s)""", tuple(request.form.get(k) for k in ["consultation_id","medication_id","dosage","frequency","duration","quantity","instructions"]))
    audit("INSERT", "prescriptions", pid, "Prescription recorded")
    return redirect(request.referrer or url_for("patients"))


@app.route("/medications")
@role_required("doctor", "nurse", "administrator")
def medications():
    rows = query("SELECT * FROM medications ORDER BY medication_name")
    return render_template("medications.html", medications=rows)


@app.post("/medications/add")
@role_required("administrator")
def add_medication():
    mid = execute("""INSERT INTO medications(medication_name,description,dosage_form,strength,quantity_available,expiry_date)
        VALUES (%s,%s,%s,%s,%s,%s)""", tuple(request.form.get(k) for k in ["medication_name","description","dosage_form","strength","quantity_available","expiry_date"]))
    audit("INSERT", "medications", mid, "Medication added to inventory")
    flash("Medication added.", "success"); return redirect(url_for("medications"))


@app.route("/audit")
@role_required("administrator")
def audit_logs():
    rows = query("""SELECT a.*,u.username FROM audit_log a JOIN users u ON u.user_id=a.user_id
        ORDER BY a.date_time DESC LIMIT 200""")
    return render_template("audit_log.html", logs=rows)


if __name__ == "__main__":
    app.run(debug=True)
