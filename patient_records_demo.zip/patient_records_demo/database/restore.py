"""Restore a MySQL backup for the Rural Clinic EPR demonstration.

Usage: python database/restore.py path/to/backup.sql
Only restore a trusted backup in a controlled environment.
"""
import os
import subprocess
import sys

if len(sys.argv) != 2:
    raise SystemExit("Usage: python database/restore.py path/to/backup.sql")

backup_file = sys.argv[1]
if not os.path.isfile(backup_file):
    raise SystemExit("Backup file does not exist.")

host = os.getenv("DB_HOST", "127.0.0.1")
user = os.getenv("DB_USER", "root")
password = os.getenv("DB_PASSWORD", "")
name = os.getenv("DB_NAME", "rural_clinic")
cmd = ["mysql", "-h", host, "-u", user, name]
env = os.environ.copy()
if password:
    env["MYSQL_PWD"] = password

with open(backup_file, "r", encoding="utf-8") as source:
    subprocess.run(cmd, stdin=source, stderr=subprocess.PIPE, text=True, env=env, check=True)

print(f"Database restored from: {backup_file}")
