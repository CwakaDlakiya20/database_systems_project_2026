import mysql.connector

def get_connection():
    connection = mysql.connector.connect(
        host="localhost",
        port=3306,
        user="root",
        password="n3wP@ssw0rd",
        database="rural_clinic"
    )

    return connection