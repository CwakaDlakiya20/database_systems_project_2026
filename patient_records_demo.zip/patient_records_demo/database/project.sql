CREATE DATABASE IF NOT EXISTS rural_clinic;
USE rural_clinic;
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS audit_log;
DROP TABLE IF EXISTS prescriptions;
DROP TABLE IF EXISTS diagnoses;
DROP TABLE IF EXISTS consultations;
DROP TABLE IF EXISTS appointments;
DROP TABLE IF EXISTS medications;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS nurses;
DROP TABLE IF EXISTS doctors;
DROP TABLE IF EXISTS patients;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE patients (
  patient_id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(80) NOT NULL,
  last_name VARCHAR(80) NOT NULL,
  date_of_birth DATE,
  gender VARCHAR(20),
  id_number VARCHAR(30) UNIQUE,
  phone_number VARCHAR(30),
  address VARCHAR(255),
  village VARCHAR(120),
  emergency_contact_name VARCHAR(120),
  emergency_contact_phone VARCHAR(30),
  date_registered DATE NOT NULL DEFAULT (CURRENT_DATE)
);

CREATE TABLE doctors (
  doctor_id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(80) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  specialisation VARCHAR(120),
  phone_number VARCHAR(30),
  email VARCHAR(150),
  hire_date DATE
);

CREATE TABLE nurses (
  nurse_id INT AUTO_INCREMENT PRIMARY KEY,
  first_name VARCHAR(80) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  qualification VARCHAR(150),
  phone_number VARCHAR(30),
  email VARCHAR(150),
  hire_date DATE
);

CREATE TABLE appointments (
  appointment_id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  doctor_id INT NOT NULL,
  appointment_date DATE NOT NULL,
  appointment_time TIME NOT NULL,
  reason VARCHAR(255),
  status ENUM('Scheduled','Completed','Cancelled','No-show') NOT NULL DEFAULT 'Scheduled',
  FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON UPDATE CASCADE ON DELETE CASCADE,
  FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id) ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE consultations (
  consultation_id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  doctor_id INT NOT NULL,
  nurse_id INT NULL,
  consultation_date DATE NOT NULL,
  symptoms TEXT,
  blood_pressure VARCHAR(20),
  temperature DECIMAL(4,1),
  weight DECIMAL(5,2),
  clinical_notes TEXT,
  treatment_notes TEXT,
  FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON UPDATE CASCADE ON DELETE CASCADE,
  FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id) ON UPDATE CASCADE ON DELETE RESTRICT,
  FOREIGN KEY (nurse_id) REFERENCES nurses(nurse_id) ON UPDATE CASCADE ON DELETE SET NULL
);

CREATE TABLE diagnoses (
  diagnosis_id INT AUTO_INCREMENT PRIMARY KEY,
  consultation_id INT NOT NULL,
  diagnosis_name VARCHAR(150) NOT NULL,
  description TEXT,
  diagnosis_date DATE NOT NULL DEFAULT (CURRENT_DATE),
  FOREIGN KEY (consultation_id) REFERENCES consultations(consultation_id) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE medications (
  medication_id INT AUTO_INCREMENT PRIMARY KEY,
  medication_name VARCHAR(150) NOT NULL,
  description TEXT,
  dosage_form VARCHAR(60),
  strength VARCHAR(60),
  quantity_available INT NOT NULL DEFAULT 0,
  expiry_date DATE
);

CREATE TABLE prescriptions (
  prescription_id INT AUTO_INCREMENT PRIMARY KEY,
  consultation_id INT NOT NULL,
  medication_id INT NOT NULL,
  dosage VARCHAR(100) NOT NULL,
  frequency VARCHAR(100) NOT NULL,
  duration VARCHAR(100) NOT NULL,
  quantity INT NOT NULL,
  instructions TEXT,
  FOREIGN KEY (consultation_id) REFERENCES consultations(consultation_id) ON UPDATE CASCADE ON DELETE CASCADE,
  FOREIGN KEY (medication_id) REFERENCES medications(medication_id) ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE TABLE users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(80) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('administrator','doctor','nurse','receptionist') NOT NULL,
  doctor_id INT NULL,
  nurse_id INT NULL,
  date_created DATE NOT NULL DEFAULT (CURRENT_DATE),
  last_login DATETIME NULL,
  account_status ENUM('Active','Disabled') NOT NULL DEFAULT 'Active',
  FOREIGN KEY (doctor_id) REFERENCES doctors(doctor_id) ON UPDATE CASCADE ON DELETE SET NULL,
  FOREIGN KEY (nurse_id) REFERENCES nurses(nurse_id) ON UPDATE CASCADE ON DELETE SET NULL
);

CREATE TABLE audit_log (
  log_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  action VARCHAR(20) NOT NULL,
  table_name VARCHAR(80) NOT NULL,
  record_id INT,
  date_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  description TEXT,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON UPDATE CASCADE ON DELETE RESTRICT
);

INSERT INTO doctors(first_name,last_name,specialisation,phone_number,email,hire_date) VALUES
('Samuel','Molefe','General Practice','0530001001','molefe@ruralclinic.local','2020-01-15'),
('Amina','Dlamini','Primary Care','0530001002','dlamini@ruralclinic.local','2021-02-01');

INSERT INTO nurses(first_name,last_name,qualification,phone_number,email,hire_date) VALUES
('Lerato','Mokoena','Professional Nurse','0530002001','mokoena@ruralclinic.local','2022-03-10'),
('Thabo','Ndlovu','Enrolled Nurse','0530002002','ndlovu@ruralclinic.local','2023-07-01');

INSERT INTO patients(first_name,last_name,date_of_birth,gender,id_number,phone_number,address,village,emergency_contact_name,emergency_contact_phone) VALUES
('Thandi','Mokoena','1989-04-17','Female','DEMO001','0710001001','12 Main Road','Village A','Nomsa Mokoena','0710001002'),
('Sipho','Dlamini','1978-11-03','Male','DEMO002','0710001003','8 Clinic Road','Village B','Zanele Dlamini','0710001004'),
('Maria','Nkosi','2001-08-25','Female','DEMO003','0710001005','4 River Road','Village C','Peter Nkosi','0710001006');

INSERT INTO medications(medication_name,description,dosage_form,strength,quantity_available,expiry_date) VALUES
('Paracetamol','Pain and fever relief','Tablet','500 mg',250,'2027-06-30'),
('Amoxicillin','Antibiotic demonstration item','Capsule','500 mg',120,'2027-03-31'),
('Oral Rehydration Salts','Rehydration treatment','Sachet','Standard',80,'2028-01-31');

INSERT INTO appointments(patient_id,doctor_id,appointment_date,appointment_time,reason,status) VALUES
(1,1,CURRENT_DATE,'09:00:00','Follow-up visit','Scheduled'),
(2,2,CURRENT_DATE,'09:30:00','General consultation','Scheduled'),
(3,1,CURRENT_DATE,'10:00:00','Routine check-up','Scheduled');

-- Demo password for all accounts: Password123!
INSERT INTO users(username,password_hash,role,doctor_id) VALUES
('doctor1','pbkdf2:sha256:600000$1dec422f173894e2$wrT26a21AdqxEg3OzoCkdFsH0Uotd0RgaiMtkrEokcI=','doctor',1);
INSERT INTO users(username,password_hash,role,nurse_id) VALUES
('nurse1','pbkdf2:sha256:600000$1dec422f173894e2$wrT26a21AdqxEg3OzoCkdFsH0Uotd0RgaiMtkrEokcI=','nurse',1);
INSERT INTO users(username,password_hash,role) VALUES
('receptionist1','pbkdf2:sha256:600000$1dec422f173894e2$wrT26a21AdqxEg3OzoCkdFsH0Uotd0RgaiMtkrEokcI=','receptionist'),
('admin','pbkdf2:sha256:600000$1dec422f173894e2$wrT26a21AdqxEg3OzoCkdFsH0Uotd0RgaiMtkrEokcI=','administrator');


USE rural_clinic;
SHOW TABLES;
SELECT* FROM patients;
SELECT username, role, account_status FROM users;
SELECT username, password_hash FROM users WHERE username= 'admin';

USE rural_clinic;
UPDATE users SET password_hash = 'scrypt:32768:8:1$Xqw5Z0Fld8bxCVw1$2b8e3ffc49bc49955f32294810c85b0bd0c651a41b428238259c55fd100f5e9466c79d192a01a0b34ff7fdc062d85b136285b561551bd085a10f30f744c231b0' WHERE username = 'admin';
COMMIT;

SELECT username, role, account_status, 
       CASE 
           WHEN password_hash IS NULL OR password_hash = '' THEN 'NO PASSWORD'
           ELSE 'PASSWORD HASH EXISTS'
       END AS password_check
FROM users;

USE rural_clinic;

UPDATE users
SET password_hash = 'scrypt:32768:8:1$ZdCqbV95dVHVgopq$4f67fbbfe89ab14ada09f7440e437e2edf30aff186b5b327b586ad4e8dd377b9d29f6ddf42859c75029d90565f2bfd5c27fecd487b457714c8afc20c5c4daeb4'
WHERE username IN ('admin', 'doctor1', 'nurse1', 'receptionist1');
COMMIT;
SHOW TABLES;
SELECT * FROM users;



