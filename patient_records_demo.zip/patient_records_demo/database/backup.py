"""Create a MySQL backup for the Rural Clinic EPR demo.
"""
import os
import subprocess
from datetime import datetime

name = os.getenv("DB_NAME", "rural_clinic")
host = os.getenv("DB_HOST", "127.0.0.1")
user = os.getenv("DB_USER", "root")
password = os.getenv("DB_PASSWORD", "n3wP@ssw0rd")
out_dir = os.path.join(os.path.dirname(__file__), "backups")
os.makedirs(out_dir, exist_ok=True)
filename = os.path.join(out_dir, f"{name}_{datetime.now():%Y%m%d_%H%M%S}.sql")

cmd = ["mysqldump", "-h", host, "-u", user, name]
env = os.environ.copy()
if password:
    env["MYSQL_PWD"] = password

with open(filename, "w", encoding="utf-8") as backup:
    subprocess.run(cmd, stdout=backup, stderr=subprocess.PIPE, text=True, env=env, check=True)

print(f"Backup created: {filename}")
