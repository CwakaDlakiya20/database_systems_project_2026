from database import get_connection

try:
    connection = get_connection()
    print("Connected to MySQL successfully!")

    cursor = connection.cursor()
    cursor.execute("SHOW TABLES")

    print("Tables:in rural clinic database:")

    for table in cursor:
        print(table[0])

    cursor.close()
    connection.close()

except Exception as e:
    print("Connection failed:")
    print(e)